class Atom(str): pass
def tokenize(s):
 import re
 return re.findall(r'\(|\)|"(?:\\.|[^"\\])*"|[^\s()]+',s)
def parse(s):
 import json
 ts=iter(tokenize(s)); stack=[]; root=None
 for t in ts:
  if t=='(':
   x=[]
   if stack: stack[-1].append(x)
   else: root=x
   stack.append(x)
  elif t==')': stack.pop()
  else: stack[-1].append(json.loads(t) if t.startswith('"') else Atom(t))
 return root
def dump(x,level=0):
 import json
 if not isinstance(x,list): return str(x) if isinstance(x,Atom) else json.dumps(x)
 if not x:return '()'
 simple=all(not isinstance(v,list) for v in x)
 if simple:return '('+' '.join(dump(v) for v in x)+')'
 return '('+dump(x[0])+''.join('\n'+'  '*(level+1)+dump(v,level+1) for v in x[1:])+'\n'+'  '*level+')'
def child(x,name):
 return next((v for v in x if isinstance(v,list) and v and v[0]==name),None)
def children(x,name):
 return [v for v in x if isinstance(v,list) and v and v[0]==name]
