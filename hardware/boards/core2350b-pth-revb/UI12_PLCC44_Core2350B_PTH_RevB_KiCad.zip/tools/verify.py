from pathlib import Path
import pcbnew as p,json,csv,sys,math
r=Path(__file__).resolve().parents[1];sys.path.insert(0,str(r/'tools'));from sexpr import parse,child,children
b=p.LoadBoard(str(r/(r.name+'.kicad_pcb')));fps={f.GetReference():f for f in b.GetFootprints()}
def pad(ref,n):return next(d for d in fps[ref].Pads() if d.GetNumber()==str(n))
def net(ref,n):return pad(ref,n).GetNetname()
assert b.GetCopperLayerCount()==4
ports={0:2,1:4,2:3,3:6,4:5,5:8,6:7,7:10,8:9,9:12,10:11,11:14,12:13,13:16,14:15,15:20,17:21,18:24,19:23,20:26,21:25}
for gpio,contact in {0:38,1:41,2:42,3:43,4:44,5:1,6:2,7:3}.items():
 assert net('U1',ports[gpio])==net('R'+str(gpio+1),1);assert net('J12',contact)==net('R'+str(gpio+1),2)
for gpio,contact,res in [(8,37,9),(9,35,10),(10,30,11),(11,31,12),(12,32,13),(13,33,14),(14,34,15),(17,19,17),(18,15,18),(20,13,19),(21,14,20)]:
 assert net('U1',ports[gpio])==net('R'+str(res),1);assert net('J12',contact)==net('R'+str(res),2)
for q,gpio,res,contact in [('Q1',15,21,36),('Q2',19,24,33)]:
 assert net('U1',ports[gpio])==net('R'+str(res),1);assert net(q,1)==net('R'+str(res),2);assert net(q,2)=='/GND';assert net(q,3)==net('J12',contact)
assert net('U1',17)=='/CORE_VBUS' and net('U1',18)=='/CORE_3V3'
assert net('J12',17)==net('J12',39)==net('D1',2)=='/IIGS_5V'
assert net('D1',1)==net('JP1',1)=='/IIGS_5V_D';assert net('JP1',2)==net('U1',17)
assert net('J12',7)==net('J12',40)==net('U1',1)==net('U1',19)=='/GND'
assert len(list(fps['J12'].Pads()))==44 and len(list(fps['U1'].Pads()))==26
coords=[]
for k in range(1,45):
 if k<=6:x,y=-1.27*(k-1),-8.7
 elif k<=17:x,y=-8.7,-6.35+1.27*(k-7)
 elif k<=28:x,y=-6.35+1.27*(k-18),8.7
 elif k<=39:x,y=8.7,6.35-1.27*(k-29)
 else:x,y=6.35-1.27*(k-40),-8.7
 d=pad('J12',k);pos=d.GetPosition();assert abs(p.ToMM(pos.x)-104.4-x)<1e-6 and abs(p.ToMM(pos.y)-100-y)<1e-6;assert abs(p.ToMM(d.GetDrillSize().x)-.65)<1e-6;assert d.GetAttribute()==p.PAD_ATTRIB_PTH
 coords.append({'pin':k,'x_mm':round(p.ToMM(pos.x),4),'y_mm':round(p.ToMM(pos.y),4),'net':d.GetNetname()})
# Module holes are not mirrored: original P1/2=GPIO0; P2/15=VBUS, P2/16=3V3.
for number,x,y in [(2,91.31,88.57),(17,93.85,88.57),(18,93.85,91.11),(21,91.31,111.43)]:
 d=pad('U1',number);pos=d.GetPosition();assert abs(p.ToMM(pos.x)-x)<1e-6 and abs(p.ToMM(pos.y)-y)<1e-6
bottom=[f.GetReference() for f in b.GetFootprints() if f.IsFlipped() and not f.GetReference().startswith('TP')];assert not bottom,bottom
tracks=[t for t in b.GetTracks() if t.GetClass()!='PCB_VIA'];minimum=min(p.ToMM(t.GetWidth()) for t in tracks);assert minimum>=.1499
result={'board_mm':[30,30],'layers':4,'PLCC44_finished_drill_mm':.65,'PLCC44_row_centres_mm':17.4,'pin_square_mm':.4,'nominal_outside_pin_span_mm':17.8,'header_pitch_mm':2.54,'GPIO_mapping':'PASS, unchanged','power_path':'IIgs5V -> D1 -> JP1 -> Core VBUS; 3V3 is output only','minimum_track_mm':round(minimum,3),'configured_clearance_mm':.2,'bottom_mounted_components':bottom,'module_clearance_requirement_mm':4,'physical_fit':'NOT TESTED','pin_protrusion':'NOT TESTED','electrical_bringup_of_this_PCB':'NOT TESTED','notes':'Core module and carrier offset by 4.2mm in X; check orientation and housing before fabrication'}
(r/'reports/audit.json').write_text(json.dumps(result,indent=2)+'\n');(r/'hardware/PLCC44_pin_map.json').write_text(json.dumps(coords,indent=2)+'\n')
with (r/'hardware/PIN_MAP.csv').open('w',newline='') as out:
 w=csv.writer(out);w.writerow(['GPIO','Carrier_U1_pad','PLCC44_contact']);
 for gpio,contact in {0:38,1:41,2:42,3:43,4:44,5:1,6:2,7:3,8:37,9:35,10:30,11:31,12:32,13:33,14:34,15:36,17:19,18:15,19:33,20:13,21:14}.items():w.writerow([gpio,ports[gpio],contact])
with (r/'BOM.csv').open('w',newline='') as out:
 w=csv.writer(out);w.writerow(['Reference','Value','Footprint','Assembly']);
 for ref,f in sorted(fps.items()):w.writerow([ref,f.GetValue(),str(f.GetFPID().GetLibItemName()),'DNP' if f.IsDNP() else 'manual module/pins' if ref in ['U1','J12'] else 'copper only' if ref.startswith('TP') or ref=='JP1' else 'SMD'])
print(json.dumps(result,indent=2))
