# Design references

Accessed 2026-10-28. Manufacturer documents take precedence over catalogue
photographs. Downloaded reference copies remain local and are not redistributed
in the project archive.

- [User-selected W9382 at Warwick](https://warwickts.com/4401/W9382-44-Way-SMT-PLCC-Plug).
- [Winslow current PLCC plug range sheet](https://www.winslowadaptics.com/app/uploads/2024/11/PLCC-Plug-Range-Datasheet.pdf), p4:
  W9382, 44 contacts, 1.27 mm pitch, A=B=16.4 mm, unsuffixed E=15.8 mm.
- [Winslow catalogue, printed p20 / PDF p22](https://kamaka.de/wp-content/uploads/2015/05/Winslow-Catalogue-1.pdf):
  small-outline W9382 land layout F=14.3 mm, G2=18.2 mm; 0.9 mm land width.
  The catalogue and newer range sheet use different dimension conventions.
  See the explicit derivation and qualification limit in hardware/MECHANICAL.md.
- [Waveshare Core2350B official schematic](https://files.waveshare.com/wiki/Core2350B0/Core2350B.pdf):
  P1/P2/P3/P4 numbering, ground, VBUS, 3V3 and onboard regulator/USB path.
- [Waveshare official dimensions](https://www.waveshare.com/w/upload/d/de/800px-Core2350B0-details-size.jpg):
  25.4 mm square body, 22.86 mm outer-hole centre span, 2.54 mm pitch.
- [Waveshare wiki](https://www.waveshare.com/wiki/Core2350B0).
- [RP2350 datasheet](https://datasheets.raspberrypi.com/rp2350/rp2350-datasheet.pdf):
  FT input-voltage conditions and silicon errata; preserve the tested powered
  interface and do not extrapolate it to arbitrary RP2350 pins/revisions.
- [Nexperia 2N7002](https://assets.nexperia.com/documents/data-sheet/2N7002.pdf):
  SOT23 gate=1, source=2, drain=3.
- Apple IIgs ROM01 schematic, part 5: original UI12/UI14 pin map, available in
  the repair workspace and supplied earlier in this conversation.
- Working project: [UI12/UI14 RP2350 firmware and prototype](https://github.com/Mamorup/apple-iigs-ui12-ui14-rp2350).

The earlier Ironwood investigation and Samtec SMT-header trial were rejected.
Neither supplies the selected W9382 footprint geometry or the final top interface.
